See https://github.com/gleitz/midi-js-soundfonts

These are local copies downloaded for standalone use, from URL

https://cdn.rawgit.com/gleitz/midi-js-Soundfonts/master/FluidR3_GM/

followed by instrument name and -ogg.js
